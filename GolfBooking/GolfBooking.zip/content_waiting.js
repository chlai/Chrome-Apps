
const queuePosition = document.getElementById("queue_position").innerText.split("\n")[1];
const updateAt =document.getElementById("last_update").innerText;
Date.now()


